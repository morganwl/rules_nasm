$NASM -v | grep NASM
